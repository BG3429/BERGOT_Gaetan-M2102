<?php
require_once("functionPHP2.php");
//Appel fonction
titre("Page2");

paragraphe("Un bouton","button");

paragrapheAvecTitre("Tableau","<tr><td>Contenu</tr></td>",2,"table");
?>
