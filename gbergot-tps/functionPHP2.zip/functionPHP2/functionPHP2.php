<?php
//D�claration d'une fonction
function titre($titre,$niveau=1){
  echo "<h{$niveau}>{$titre}</h{$niveau}>";   
}
//
function paragraphe($texte,$element="div"){
  echo "<{$element}>{$texte}</{$element}>";
}
//
function paragrapheAvecTitre($titre,$texte="",$niveau=1,$element="div"){
  titre($titre,$niveau);
  paragraphe($texte,$element);
}
?>